﻿namespace Bomb_WinForms
{
    partial class GameForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            chooseMapToolStripMenuItem = new ToolStripMenuItem();
            smallMap = new ToolStripMenuItem();
            mediumMap = new ToolStripMenuItem();
            largeMap = new ToolStripMenuItem();
            pauseGame = new ToolStripMenuItem();
            gameResult = new ToolStripMenuItem();
            menuStrip2 = new MenuStrip();
            gameTime = new ToolStripMenuItem();
            gameScore = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            menuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { chooseMapToolStripMenuItem, pauseGame, gameResult });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(946, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // chooseMapToolStripMenuItem
            // 
            chooseMapToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { smallMap, mediumMap, largeMap });
            chooseMapToolStripMenuItem.Name = "chooseMapToolStripMenuItem";
            chooseMapToolStripMenuItem.Size = new Size(86, 20);
            chooseMapToolStripMenuItem.Text = "Choose map";
            // 
            // smallMap
            // 
            smallMap.Name = "smallMap";
            smallMap.Size = new Size(119, 22);
            smallMap.Text = "Small";
            smallMap.Click += smallMap_Click;
            // 
            // mediumMap
            // 
            mediumMap.Name = "mediumMap";
            mediumMap.Size = new Size(119, 22);
            mediumMap.Text = "Medium";
            mediumMap.Click += mediumMap_Click;
            // 
            // largeMap
            // 
            largeMap.Name = "largeMap";
            largeMap.Size = new Size(119, 22);
            largeMap.Text = "Large";
            largeMap.Click += largeMap_Click;
            // 
            // pauseGame
            // 
            pauseGame.Name = "pauseGame";
            pauseGame.Size = new Size(43, 20);
            pauseGame.Text = "Start";
            pauseGame.Click += Pause_Click;
            // 
            // gameResult
            // 
            gameResult.Name = "gameResult";
            gameResult.Size = new Size(22, 20);
            gameResult.Text = " ";
            // 
            // menuStrip2
            // 
            menuStrip2.Dock = DockStyle.Bottom;
            menuStrip2.Items.AddRange(new ToolStripItem[] { gameTime, gameScore });
            menuStrip2.Location = new Point(0, 1017);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(946, 24);
            menuStrip2.TabIndex = 1;
            menuStrip2.Text = "menuStrip2";
            // 
            // gameTime
            // 
            gameTime.Name = "gameTime";
            gameTime.Size = new Size(45, 20);
            gameTime.Text = "Time";
            // 
            // gameScore
            // 
            gameScore.Name = "gameScore";
            gameScore.Size = new Size(48, 20);
            gameScore.Text = "Score";
            // 
            // GameForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(946, 1041);
            Controls.Add(menuStrip1);
            Controls.Add(menuStrip2);
            MainMenuStrip = menuStrip1;
            Name = "GameForm";
            Text = "Bomberman";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem chooseMapToolStripMenuItem;
        private ToolStripMenuItem smallMap;
        private ToolStripMenuItem mediumMap;
        private ToolStripMenuItem largeMap;
        private ToolStripMenuItem pauseGame;
        private MenuStrip menuStrip2;
        private ToolStripMenuItem gameTime;
        private ToolStripMenuItem gameScore;
        private ToolStripMenuItem gameResult;
    }
}