using Bomb.Model;
using Bomb.Persistence;
using System.Diagnostics;
using System.Drawing.Text;

namespace Bomb_WinForms
{
    public partial class GameForm : Form
    {
        private IMapFileDataAccess _dataAccess = null!;
        private BombGameModel _model = null!;
        private Button[,] _buttonGrid = null!;

        private System.Windows.Forms.Timer MoveTimer = null!;
        private System.Windows.Forms.Timer GameTimer = null!;

        private bool paused;
        private bool mapGenerated;
        private bool over;
        private int time;

        public GameForm()
        {
            InitializeComponent();

            _dataAccess = new MapFileDataAccess();
            _model = new BombGameModel(_dataAccess);

            paused = true;
            mapGenerated = false;
            over = false;
            time = 0;

            MoveTimer = new System.Windows.Forms.Timer();
            MoveTimer.Interval = 1500;
            MoveTimer.Tick += new EventHandler(MoveTimer_Tick!);

            GameTimer = new System.Windows.Forms.Timer();
            GameTimer.Interval = 1000;
            GameTimer.Tick += new EventHandler(GameTimer_Tick!);

            _model.GameOver += new EventHandler<BombGameEventArgs>(GameOver);
            _model.GameWon += new EventHandler<BombGameEventArgs>(GameWon);

            this.KeyDown += new KeyEventHandler(PlayerControls!);
        }

        #region Player controls

        private void PlayerControls(object sender, KeyEventArgs e)
        {
            if (!paused)
            {
                ClearEntities();
                switch (e.KeyCode)
                {
                    case Keys.Left:
                        if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y - 1] != 1)
                        {
                            _model.Player.MoveUp();
                        }
                        break;
                    case Keys.Right:
                        if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y + 1] != 1)
                        {
                            _model.Player.MoveDown();
                        }
                        break;
                    case Keys.Up:
                        if (_model.Map.ObjectMatrix[_model.Player.X - 1, _model.Player.Y] != 1)
                        {
                            _model.Player.MoveLeft();
                        }
                        break;
                    case Keys.Down:
                        if (_model.Map.ObjectMatrix[_model.Player.X + 1, _model.Player.Y] != 1)
                        {
                            _model.Player.MoveRight();
                        }
                        break;
                    case Keys.Space:
                        _model.PlaceBomb();
                        break;
                }
                DrawEntities();
                for (int i = 0; i < _model.Enemies.Count; i++)
                {
                    _model.IsHit(_model.Enemies[i]);
                }
            }
        }

        #endregion

        private void MoveTimer_Tick(object sender, EventArgs e)
        {
            ClearEntities();
            _model.MoveEnemies();
            DrawEntities();
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            time++;
            gameTime.Text = "Time: " + time;

            ClearEntities();
            _model.UpdateGameState();

            gameScore.Text = "Score: " + _model.Score;
            DrawEntities();
        }

        private void GameOver(Object? sender, BombGameEventArgs e)
        {
            paused = true;
            over = true;
            MoveTimer.Stop();
            GameTimer.Stop();
            gameResult.Text = "You died";
        }

        private void GameWon(Object? sender, BombGameEventArgs e)
        {
            paused = true;
            over = true;
            MoveTimer.Stop();
            GameTimer.Stop();
            gameResult.Text = "You won";
        }

        private void Pause_Click(object sender, EventArgs e)
        {
            if (mapGenerated && !over)
            {
                if (!paused)
                {
                    paused = true;
                    MoveTimer.Stop();
                    GameTimer.Stop();
                    pauseGame.Text = "Start";
                }
                else
                {
                    paused = false;
                    pauseGame.Text = "Pause";
                    MoveTimer.Start();
                    GameTimer.Start();
                }
            }
        }

        private async void smallMap_Click(object sender, EventArgs e)
        {
            await _model.LoadGameMap(MapSize.Small);
            this.Width = 700;
            this.Height = 750;
            GenerateGame();
            mapGenerated = true;
        }

        private async void mediumMap_Click(object sender, EventArgs e)
        {
            await _model.LoadGameMap(MapSize.Medium);
            this.Width = 1000;
            this.Height = 1050;
            GenerateGame();
            mapGenerated = true;
        }

        private async void largeMap_Click(object sender, EventArgs e)
        {
            await _model.LoadGameMap(MapSize.Large);
            this.Width = 1300;
            this.Height = 1350;
            GenerateGame();
            mapGenerated = true;
        }

        private void GenerateGame()
        {
            over = false;
            paused = true;
            _model.Score = 0;
            _model.Bombs.Clear();
            time = 0;
            gameResult.Text = " ";
            gameScore.Text = "Score: ";
            gameTime.Text = "Time: ";
            pauseGame.Text = "Start";

            MoveTimer.Stop();
            GameTimer.Stop();

            _model.Enemies.Clear();
            if (mapGenerated)
            {
                ResetGrid();
                ClearEntities();
            }
            GenerateMap();
            DrawWalls();
            _model.SpawnEntities();

            for (int i = 0; i < _model.Enemies.Count; i++)
            {
                _model.RandomEnemyDir(_model.Enemies[i]);
            }

            DrawEntities();
        }

        private void GenerateMap()
        {
            _buttonGrid = new Button[_model.Map.MapSize, _model.Map.MapSize];
            for (int i = 0; i < _model.Map.MapSize; i++)
            {
                for (int j = 0; j < _model.Map.MapSize; j++)
                {
                    _buttonGrid[i, j] = new Button();
                    _buttonGrid[i, j].Location = new Point(5 + 50 * j, 35 + 50 * i);
                    _buttonGrid[i, j].Size = new Size(50, 50);
                    _buttonGrid[i, j].Font = new Font(FontFamily.GenericSansSerif, 25, FontStyle.Bold);
                    _buttonGrid[i, j].Enabled = false;
                    _buttonGrid[i, j].TabIndex = 100 + i * _model.Map.MapSize + j;
                    _buttonGrid[i, j].FlatStyle = FlatStyle.Flat;

                    Controls.Add(_buttonGrid[i, j]);
                }
            }
        }

        private void DrawWalls()
        {
            for (int i = 0; i < _model.Map.MapSize; i++)
            {
                for (int j = 0; j < _model.Map.MapSize; j++)
                {
                    if (_model.Map.ObjectMatrix[i, j] == 1)
                    {
                        _buttonGrid[i, j].BackColor = Color.Gray;
                    }
                }
            }
        }

        private void DrawEntities()
        {
            _buttonGrid[_model.Player.X, _model.Player.Y].BackColor = Color.Blue;
            for (int i = 0; i < _model.Enemies.Count; i++)
            {
                _buttonGrid[_model.Enemies[i].X, _model.Enemies[i].Y].BackColor = Color.Red;
            }
            for (int i = 0; i < _model.Bombs.Count; i++)
            {
                _buttonGrid[_model.Bombs[i].X, _model.Bombs[i].Y].BackColor = Color.Black;
            }
        }

        private void ClearEntities()
        {
            _buttonGrid[_model.Player.X, _model.Player.Y].BackColor = Color.White;
            for (int i = 0; i < _model.Enemies.Count; i++)
            {
                _buttonGrid[_model.Enemies[i].X, _model.Enemies[i].Y].BackColor = Color.White;
            }
            for (int i = 0; i < _model.Bombs.Count; i++)
            {
                _buttonGrid[_model.Bombs[i].X, _model.Bombs[i].Y].BackColor = Color.White;
            }
        }

        private void ResetGrid()
        {
            foreach (var button in _buttonGrid)
            {
                Controls.Remove(button);
            }
        }
    }
}