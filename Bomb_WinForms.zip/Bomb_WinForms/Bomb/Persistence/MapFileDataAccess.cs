﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Persistence
{
    public class MapFileDataAccess : IMapFileDataAccess
    {
        public async Task<Map> LoadMap(String path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    String line = await reader.ReadLineAsync() ?? String.Empty;
                    int mapSize = int.Parse(line);
                    Map map = new Map(mapSize);

                    for (int i = 0; i < mapSize; i++)
                    {
                        line = await reader.ReadLineAsync() ?? String.Empty;

                        for (int j = 0; j < mapSize; j++)
                        {
                            map.SetObject(i, j, int.Parse(line[j].ToString()));
                        }
                    }

                    return map;
                }
            }
            catch
            {
                throw new MapFileDataException();
            }
        }
    }
}
