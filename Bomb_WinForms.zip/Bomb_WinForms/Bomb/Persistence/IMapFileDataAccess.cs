﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Persistence
{
    public interface IMapFileDataAccess 
    {
        Task<Map> LoadMap(String path);
    }
}