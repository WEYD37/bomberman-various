﻿using Bomb.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Persistence
{
    public class Map
    {
        private int _mapSize;
        private int[,] _objectMatrix;

        public int MapSize { get { return _mapSize; } }
        public int[,] ObjectMatrix { get { return _objectMatrix; } set { _objectMatrix = value; } }

        public Map(int mapSize)
        {
            _mapSize = mapSize;
            _objectMatrix = new int[mapSize, mapSize];
        }

        public void SetObject(int x, int y, int objectValue)
        {
            _objectMatrix[x, y] = objectValue;
        }
    }
}