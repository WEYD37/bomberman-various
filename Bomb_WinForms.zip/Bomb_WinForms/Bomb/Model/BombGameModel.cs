﻿using Bomb.Persistence;

namespace Bomb.Model
{
    public enum MapSize { Small, Medium, Large }

    public class BombGameModel
    {
        private IMapFileDataAccess _dataAccess;
        private Map _map = null!;

        private Player _player = null!;
        private List<Enemy> _enemies = new List<Enemy>();
        private List<Bomb> _bombs = new List<Bomb>();

        private Random _random;

        private int _bombDelay = 0;
        private int _score = 0;

        public Map Map { get { return _map; } }
        public Player Player { get { return _player; } }
        public List<Enemy> Enemies { get { return _enemies; } }
        public List<Bomb> Bombs { get { return _bombs; } }

        public event EventHandler<BombGameEventArgs> GameOver = null!;
        public event EventHandler<BombGameEventArgs> GameWon = null!;

        public int Score { get { return _score; } set { _score = value; } }

        public BombGameModel(IMapFileDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
            _random = new Random();
        }

        public void SpawnEntities()
        {
            for (int i = 0; i < _map.MapSize; i++)
            {
                for (int j = 0; j < _map.MapSize; j++)
                {
                    if (_map.ObjectMatrix[i, j] == 3)
                    {
                        _enemies.Add(new Enemy(i, j));
                    }
                    if (_map.ObjectMatrix[i, j] == 2)
                    {
                        _player = new Player(i, j);
                    }
                }
            }
        }

        public void RandomEnemyDir(Enemy enemy)
        {
            switch (_random.Next(4))
            {
                case 0:
                    enemy.Direction = Direction.Up; break;
                case 1:
                    enemy.Direction = Direction.Down; break;
                case 2:
                    enemy.Direction = Direction.Left; break;
                case 3:
                    enemy.Direction = Direction.Right; break;
            }

        }

        public void MoveEnemies()
        {
            for (int i = 0; i < _enemies.Count; i++)
            {
                switch (_enemies[i].Direction)
                {
                    case Direction.Up:
                        if (_map.ObjectMatrix[_enemies[i].X, _enemies[i].Y - 1] != 1)
                        {
                            _enemies[i].MoveUp();
                        }
                        else
                        {
                            RandomEnemyDir(_enemies[i]);
                        }
                        break;
                    case Direction.Down:
                        if (_map.ObjectMatrix[_enemies[i].X, _enemies[i].Y + 1] != 1)
                        {
                            _enemies[i].MoveDown();
                        }
                        else
                        {
                            RandomEnemyDir(_enemies[i]);
                        }
                        break;
                    case Direction.Left:
                        if (_map.ObjectMatrix[_enemies[i].X - 1, _enemies[i].Y] != 1)
                        {
                            _enemies[i].MoveLeft();
                        }
                        else
                        {
                            RandomEnemyDir(_enemies[i]);
                        }
                        break;
                    case Direction.Right:
                        if (_map.ObjectMatrix[_enemies[i].X + 1, _enemies[i].Y] != 1)
                        {
                            _enemies[i].MoveRight();
                        }
                        else
                        {
                            RandomEnemyDir(_enemies[i]);
                        }
                        break;
                }
                IsHit(_enemies[i]);
            }
        }

        public void UpdateGameState()
        {
            _bombDelay += 1;

            List<Enemy> enemiesToRemove = new List<Enemy>();
            List<Bomb> bombsToRemove = new List<Bomb>();

            for (int i = 0; i < _bombs.Count; i++)
            {
                _bombs[i].CountDown();
                if (_bombs[i].Time == 0)
                {
                    foreach (var enemy in _enemies)
                    {
                        if (ExplodeBomb(_bombs[i], enemy))
                        {
                            enemiesToRemove.Add(enemy);
                            _score++;
                        }
                    }

                    if (ExplodeBomb(_bombs[i], _player))
                    {
                        OnGameOver(true);
                    }

                    bombsToRemove.Add(_bombs[i]);
                }
            }

            foreach (var bomb in bombsToRemove)
            {
                _bombs.Remove(bomb);
            }

            foreach (var enemy in enemiesToRemove)
            {
                _enemies.Remove(enemy);
            }

            AllDead(_enemies);
        }


        public void PlaceBomb()
        {
            if (_bombDelay >= 2)
            {
                _bombs.Add(new Bomb(_player.X, _player.Y));
                _bombDelay = 0;
            }
        }

        public bool ExplodeBomb(Bomb bomb, Entity entity) 
        {
            int bombX = bomb.X;
            int bombY = bomb.Y;
            int entityX = entity.X;
            int entityY = entity.Y;

            return (entityX >= bombX - 3 && entityX <= bombX + 3) &&
                   (entityY >= bombY - 3 && entityY <= bombY + 3);
        }

        public void OnGameOver(bool isGameOver)
        {
            GameOver?.Invoke(this, new BombGameEventArgs(isGameOver, false));
        }

        public void OnGameWon(bool isGameWon)
        {
            GameWon?.Invoke(this, new BombGameEventArgs(false, isGameWon));
        }

        public void IsHit(Enemy enemy)
        {
            if (_player.X == enemy.X && _player.Y == enemy.Y)
            {
                OnGameOver(true);
            }
        }

        public void AllDead(List<Enemy> enemies)
        {
            if (enemies.Count == 0)
            {
                OnGameWon(true);
            }
        }

        public async Task LoadGameMap(MapSize mapSize)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            switch (mapSize)
            {
                case MapSize.Small:
                    _map = await _dataAccess.LoadMap("Persistence/small.txt");
                    break;
                case MapSize.Medium:
                    _map = await _dataAccess.LoadMap("Persistence/medium.txt");
                    break;
                case MapSize.Large:
                    _map = await _dataAccess.LoadMap("Persistence/large.txt");
                    break;
            }
        }
    }
}