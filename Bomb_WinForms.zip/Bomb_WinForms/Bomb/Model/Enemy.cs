﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Model
{
    public enum Direction {Up, Down, Left, Right}
    public class Enemy : Entity
    {
        private Direction _direction;
        public Direction Direction { get { return _direction; } set { _direction = value; } }

        public Enemy(int x, int y) : base(x, y)
        {
            _direction = Direction.Up;
        }
    }
}
