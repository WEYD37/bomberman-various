﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Model
{
    public class Bomb : Entity
    {
        private int _time;
        public int Time { get { return _time; } set { _time = value; } }
        public Bomb(int x, int y) : base(x, y)
        {
            _time = 3;
        }

        public void CountDown()
        {
            _time -= 1;
        }
    }
}
