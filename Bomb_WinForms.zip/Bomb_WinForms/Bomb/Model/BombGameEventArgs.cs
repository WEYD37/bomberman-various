﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Model
{
    public class BombGameEventArgs : EventArgs
    {
        private bool _gameOver;
        private bool _gameWon;

        public bool GameOver { get { return _gameOver; } }
        public bool GameWon { get { return _gameWon; } }

        public BombGameEventArgs(bool gameOver, bool gameWon)
        {
            _gameOver = gameOver;
            _gameWon = gameWon;
        }
    }
}
