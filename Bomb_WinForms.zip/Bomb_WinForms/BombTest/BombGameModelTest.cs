using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Bomb.Model;
using Bomb.Persistence;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Bomb.Test
{
    [TestClass]
    public class BombGameModelTest
    {
        private BombGameModel _model = null!;
        private Mock<IMapFileDataAccess> _mock = null!;
        private Map _mockedMap = null!;

        [TestInitialize]
        public async Task Initialize()
        {
            _mockedMap = new Map(13);
            _mockedMap.ObjectMatrix = new int[13, 13];
            _mockedMap.ObjectMatrix[1, 1] = 2;
            _mockedMap.ObjectMatrix[2, 2] = 3;

            _mock = new Mock<IMapFileDataAccess>();
            _mock.Setup(mock => mock.LoadMap(It.IsAny<string>()))
                .ReturnsAsync(_mockedMap);

            _model = new BombGameModel(_mock.Object);

            await _model.LoadGameMap(MapSize.Small);
        }

        [TestMethod]
        public void BombGameModelInitializationTest()
        {
            Assert.IsNotNull(_model);
            Assert.IsNotNull(_mockedMap);
        }

        [TestMethod]
        public void SpawnEntitiesTest()
        {
            _model.SpawnEntities();

            Assert.IsNotNull(_model.Player);
            Assert.AreEqual(1, _model.Player.X);
            Assert.AreEqual(1, _model.Player.Y);

            Assert.AreEqual(1, _model.Enemies.Count);
            Assert.AreEqual(2, _model.Enemies[0].X);
            Assert.AreEqual(2, _model.Enemies[0].Y);
        }

        [TestMethod]
        public void PlaceBombTest()
        {
            _model.SpawnEntities();

            typeof(BombGameModel).GetField("_bombDelay", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                                 ?.SetValue(_model, 2);

            _model.PlaceBomb();

            Assert.AreEqual(1, _model.Bombs.Count);

            var bomb = _model.Bombs[0];
            Assert.AreEqual(_model.Player.X, bomb.X);
            Assert.AreEqual(_model.Player.Y, bomb.Y);
        }


        [TestMethod]
        public void MoveEnemiesTest()
        {
            _model.SpawnEntities();
            var enemy = _model.Enemies[0];
            enemy.Direction = Direction.Up;

            _model.MoveEnemies();

            Assert.AreEqual(Direction.Up, enemy.Direction);
        }

        [TestMethod]
        public void UpdateGameStateTest()
        {
            _model.SpawnEntities();

            typeof(BombGameModel).GetField("_bombDelay", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                                 ?.SetValue(_model, 2);

            _model.PlaceBomb();

            Assert.AreEqual(1, _model.Bombs.Count);

            var bomb = _model.Bombs[0];
            bomb.Time = 1;

            _model.UpdateGameState();

            Assert.AreEqual(0, _model.Bombs.Count);

            Assert.AreEqual(1, _model.Score);

            Assert.AreEqual(0, _model.Enemies.Count);

            _model.SpawnEntities();
            var enemy = _model.Enemies[0];
            _model.Player.X = enemy.X;
            _model.Player.Y = enemy.Y;

            bool gameOverTriggered = false;
            _model.GameOver += (sender, args) => gameOverTriggered = true;

            _model.IsHit(enemy);

            Assert.IsTrue(gameOverTriggered);
        }



        [TestMethod]
        public void IsHitTest()
        {
            _model.SpawnEntities();

            Assert.IsNotNull(_model.Player);
            Assert.IsTrue(_model.Enemies.Count > 0);

            var enemy = _model.Enemies[0];

            _model.Player.X = enemy.X;
            _model.Player.Y = enemy.Y;

            bool gameOverTriggered = false;
            _model.GameOver += (sender, args) => gameOverTriggered = true;

            _model.IsHit(enemy);

            Assert.IsTrue(gameOverTriggered);
        }
    }
}
