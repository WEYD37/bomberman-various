﻿namespace Bomb.Model
{
    public enum Direction { Up, Down, Left, Right }
    public class Enemy : Entity
    {
        public Direction Direction { get; set; }

        public Enemy(int x, int y) : base(x, y)
        {
            Direction = Direction.Up;
        }
    }
}
