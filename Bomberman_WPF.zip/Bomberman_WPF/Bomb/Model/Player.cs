﻿namespace Bomb.Model
{
    public class Player : Entity
    {
        public Player(int x, int y) : base(x, y) { }
    }
}
