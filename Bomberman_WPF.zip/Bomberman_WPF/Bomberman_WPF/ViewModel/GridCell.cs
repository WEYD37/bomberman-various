﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Bomberman_WPF.ViewModel
{
    public class GridCell : ViewModelBase
    {
        public int X { get; set; }
        public int Y { get; set; }

        private Brush _color = null!;
        public Brush Color
        {
            get => _color;
            set { _color = value; OnPropertyChanged(); }
        }
    }
}