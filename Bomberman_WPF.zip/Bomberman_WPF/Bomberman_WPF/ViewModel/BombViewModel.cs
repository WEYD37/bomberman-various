﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using Bomb.Model;
using System.Windows.Media;
using Bomb.Persistence;
using Bomberman_WPF.ViewModel;
using System;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using System.Windows;

namespace Bomberman_WPF.ViewModel
{
    public class BombViewModel : ViewModelBase
    {
        private BombGameModel _model;
        private ObservableCollection<GridCell> _gameGrid;
        private int _mapSize;

        private bool _isPaused;
        private bool _isOver;
        private int _time;

        public bool IsPaused
        {
            get => _isPaused;
            private set
            {
                _isPaused = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(StartPauseLabel));
            }
        }
        public bool IsOver
        {
            get => _isOver;
            private set
            {
                _isOver = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(StartPauseLabel));
            }
        }

        public int Time
        {
            get => _time;
            set
            {
                _time = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(FormattedTime));
            }
        }

        public string StartPauseLabel => IsPaused ? "Start" : "Pause";
        public string GameScore => $"Score: {_model.Score}";
        public string FormattedTime => $"Time: {Time / 60:D2}:{Time % 60:D2}";


        public DelegateCommand SmallMapCommand { get; private set; }
        public DelegateCommand MediumMapCommand { get; private set; }
        public DelegateCommand LargeMapCommand { get; private set; }
        public DelegateCommand PlaceBombCommand { get; private set; }
        public DelegateCommand StartGameCommand { get; private set; }

        public ObservableCollection<GridCell> GameGrid
        {
            get => _gameGrid;
            private set { _gameGrid = value; OnPropertyChanged(); }
        }

        public int MapSize
        {
            get => _mapSize;
            private set { _mapSize = value; OnPropertyChanged(); }
        }

        public BombViewModel(BombGameModel model)
        {
            _model = model;
            _model.GameOver += OnGameOver;
            _model.GameWon += OnGameWon;
            _model.ScoreChanged += OnScoreChanged; // Subscribe to score changes
            _gameGrid = new ObservableCollection<GridCell>();

            SmallMapCommand = new DelegateCommand(async _ => await LoadMap(Bomb.Model.MapSize.Small));
            MediumMapCommand = new DelegateCommand(async _ => await LoadMap(Bomb.Model.MapSize.Medium));
            LargeMapCommand = new DelegateCommand(async _ => await LoadMap(Bomb.Model.MapSize.Large));

            PlaceBombCommand = new DelegateCommand(_ => PlaceBomb());
            StartGameCommand = new DelegateCommand(_ => ToggleGamePause());

            IsPaused = true;
            Time = 0;
        }

        private void OnScoreChanged(object? sender, EventArgs e)
        {
            OnPropertyChanged(nameof(GameScore));
        }

        private void OnGameOver(object? sender, BombGameEventArgs e)
        {
            IsPaused = true;
            IsOver = true;
            MessageBox.Show("Game Over!", "Game Over", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void OnGameWon(object? sender, BombGameEventArgs e)
        {
            IsPaused = true;
            IsOver = true;
            MessageBox.Show("You Win!", "Victory", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public void PlaceBomb()
        {
            if (!IsPaused)
            {
                _model.PlaceBomb();
            }
        }

        private async Task LoadMap(MapSize mapSize)
        {
            IsPaused = true;
            IsOver = false;
            Time = 0;
            _model.Score = 0;
            await _model.LoadGameMap(mapSize);
            MapSize = _model.Map.MapSize;

            _model.Enemies.Clear();
            GenerateGameGrid();
            _model.SpawnEntities();
        }

        private void GenerateGameGrid()
        {
            GameGrid.Clear();

            for (int i = 0; i < _model.Map.MapSize; i++)
            {
                for (int j = 0; j < _model.Map.MapSize; j++)
                {
                    var cell = new GridCell
                    {
                        X = i,
                        Y = j,
                        Color = GetCellColor(_model.Map.ObjectMatrix[i, j])
                    };
                    GameGrid.Add(cell);
                }
            }
        }

        private Brush GetCellColor(int value)
        {
            return value switch
            {
                1 => Brushes.Gray,
                2 => Brushes.Blue,
                3 => Brushes.Red,
                _ => Brushes.White,
            };
        }

        public void ToggleGamePause()
        {
            if (!IsOver)
            {
                IsPaused = !IsPaused;
            }
        }

        public void IncrementTime()
        {
            if (!IsPaused)
            {
                Time++;
            }
        }
    }
}