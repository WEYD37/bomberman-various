﻿using Bomb.Model;
using Bomb.Persistence;
using Bomberman_WPF.ViewModel;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace Bomberman_WPF
{
    public partial class App : Application
    {
        private BombGameModel _model = null!;
        private BombViewModel _viewModel = null!;
        private MainWindow _view = null!;
        private DispatcherTimer _gameTimer = null!;

        public App()
        {
            Startup += App_Startup;
        }

        private void App_Startup(object sender, StartupEventArgs e)
        {
            _model = new BombGameModel(new MapFileDataAccess());

            _viewModel = new BombViewModel(_model);

            _view = new MainWindow
            {
                DataContext = _viewModel
            };
            _view.Show();

            _view.KeyDown += PlayerKeyDown;

            _gameTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _gameTimer.Tick += GameTimer_Tick;
            _gameTimer.Start();
        }

        private void PlayerKeyDown(object sender, KeyEventArgs e)
        {
            if (!_viewModel.IsPaused)
            {
                // Clear previous player position
                UpdateCell(_model.Player.X, _model.Player.Y, Brushes.White);

                // Handle movement based on key press
                switch (e.Key)
                {
                    case Key.Left:
                        if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y - 1] != 1)
                        {
                            _model.Player.MoveUp();
                        }
                        break;
                    case Key.Right:
                        if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y + 1] != 1)
                        {
                            _model.Player.MoveDown();
                        }
                        break;
                    case Key.Up:
                        if (_model.Map.ObjectMatrix[_model.Player.X - 1, _model.Player.Y] != 1)
                        {
                            _model.Player.MoveLeft();
                        }
                        break;
                    case Key.Down:
                        if (_model.Map.ObjectMatrix[_model.Player.X + 1, _model.Player.Y] != 1)
                        {
                            _model.Player.MoveRight();
                        }
                        break;
                    case Key.Space:
                        _viewModel.PlaceBombCommand.Execute(null);
                        break;
                }

                // Update the player position on the grid
                UpdateCell(_model.Player.X, _model.Player.Y, Brushes.Blue);

                // Check if the player collides with any enemy
                foreach (var enemy in _model.Enemies)
                {
                    _model.IsHit(enemy);
                }
            }
        }

        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            if (_viewModel.IsPaused || _model.Map == null)
            {
                return;
            }

            ClearEntities();
            _model.MoveEnemies();
            _model.UpdateGameState();
            DrawEntities();

            _viewModel.IncrementTime();
        }


        private void UpdateCell(int x, int y, Brush color)
        {
            var cell = _viewModel.GameGrid.FirstOrDefault(c => c.X == x && c.Y == y);
            if (cell != null)
            {
                cell.Color = color;
            }
        }

        private void DrawEntities()
        {
            UpdateCell(_model.Player.X, _model.Player.Y, Brushes.Blue);
            for (int i = 0; i < _model.Enemies.Count; i++)
            {
                UpdateCell(_model.Enemies[i].X, _model.Enemies[i].Y, Brushes.Red);
            }
            for (int i = 0; i < _model.Bombs.Count; i++)
            {
                UpdateCell(_model.Bombs[i].X, _model.Bombs[i].Y, Brushes.Black);
            }
        }

        private void ClearEntities()
        {
            UpdateCell(_model.Player.X, _model.Player.Y, Brushes.White);
            for (int i = 0; i < _model.Enemies.Count; i++)
            {
                UpdateCell(_model.Enemies[i].X, _model.Enemies[i].Y, Brushes.White);
            }
            for (int i = 0; i < _model.Bombs.Count; i++)
            {
                UpdateCell(_model.Bombs[i].X, _model.Bombs[i].Y, Brushes.White);
            }
        }
    }
}
