﻿namespace Bomb.Model
{
    public class BombGameEventArgs : EventArgs
    {
        public bool GameOver { get; }
        public bool GameWon { get; }

        public BombGameEventArgs(bool gameOver, bool gameWon)
        {
            GameOver = gameOver;
            GameWon = gameWon;
        }
    }
}