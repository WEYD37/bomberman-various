﻿namespace Bomb.Model
{
    public class Bomb : Entity
    {
        public int Time { get; set; }
        public Bomb(int x, int y) : base(x, y)
        {
            Time = 3;
        }

        public void CountDown()
        {
            Time -= 1;
        }
    }
}
