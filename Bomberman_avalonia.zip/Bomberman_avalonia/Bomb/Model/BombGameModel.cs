﻿using Bomb.Persistence;
using System.Reflection;

namespace Bomb.Model
{
    public enum MapSize { Small, Medium, Large }

    public class BombGameModel
    {
        private readonly IMapFileDataAccess _dataAccess;
        private readonly Random _random;

        private int _bombDelay = 0;
        private int _score = 0;

        public event EventHandler? ScoreChanged;

        public int Score
        {
            get => _score;
            set
            {
                _score = value;
                ScoreChanged?.Invoke(this, EventArgs.Empty);
            }
        }

        public Map Map { get; private set; } = null!;
        public Player Player { get; private set; } = null!;
        public List<Enemy> Enemies { get; } = new List<Enemy>();
        public List<Bomb> Bombs { get; } = new List<Bomb>();

        public event EventHandler<BombGameEventArgs> GameOver = null!;
        public event EventHandler<BombGameEventArgs> GameWon = null!;

        public BombGameModel(IMapFileDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
            _random = new Random();
        }

        public void SpawnEntities()
        {
            for (int i = 0; i < Map.MapSize; i++)
            {
                for (int j = 0; j < Map.MapSize; j++)
                {
                    if (Map.ObjectMatrix[i, j] == 3)
                    {
                        Enemies.Add(new Enemy(i, j));
                    }
                    if (Map.ObjectMatrix[i, j] == 2)
                    {
                        Player = new Player(i, j);
                    }
                }
            }
        }

        public void RandomEnemyDir(Enemy enemy)
        {
            switch (_random.Next(4))
            {
                case 0:
                    enemy.Direction = Direction.Up; break;
                case 1:
                    enemy.Direction = Direction.Down; break;
                case 2:
                    enemy.Direction = Direction.Left; break;
                case 3:
                    enemy.Direction = Direction.Right; break;
                default:
                    break;
            }

        }

        public void MoveEnemies()
        {
            for (int i = 0; i < Enemies.Count; i++)
            {
                switch (Enemies[i].Direction)
                {
                    case Direction.Up:
                        if (Map.ObjectMatrix[Enemies[i].X, Enemies[i].Y - 1] != 1)
                        {
                            Enemies[i].MoveUp();
                        }
                        else
                        {
                            RandomEnemyDir(Enemies[i]);
                        }
                        break;
                    case Direction.Down:
                        if (Map.ObjectMatrix[Enemies[i].X, Enemies[i].Y + 1] != 1)
                        {
                            Enemies[i].MoveDown();
                        }
                        else
                        {
                            RandomEnemyDir(Enemies[i]);
                        }
                        break;
                    case Direction.Left:
                        if (Map.ObjectMatrix[Enemies[i].X - 1, Enemies[i].Y] != 1)
                        {
                            Enemies[i].MoveLeft();
                        }
                        else
                        {
                            RandomEnemyDir(Enemies[i]);
                        }
                        break;
                    case Direction.Right:
                        if (Map.ObjectMatrix[Enemies[i].X + 1, Enemies[i].Y] != 1)
                        {
                            Enemies[i].MoveRight();
                        }
                        else
                        {
                            RandomEnemyDir(Enemies[i]);
                        }
                        break;
                    default:
                        break;
                }
                IsHit(Enemies[i]);
            }
        }

        public void UpdateGameState()
        {
            _bombDelay += 1;

            List<Enemy> enemiesToRemove = new();
            List<Bomb> bombsToRemove = new();

            for (int i = 0; i < Bombs.Count; i++)
            {
                Bombs[i].CountDown();
                if (Bombs[i].Time == 0)
                {
                    foreach (Enemy enemy in Enemies)
                    {
                        if (ExplodeBomb(Bombs[i], enemy))
                        {
                            enemiesToRemove.Add(enemy);
                            Score++;
                        }
                    }

                    if (ExplodeBomb(Bombs[i], Player))
                    {
                        OnGameOver(true);
                        return;
                    }

                    bombsToRemove.Add(Bombs[i]);
                }
            }

            foreach (Bomb bomb in bombsToRemove)
            {
                _ = Bombs.Remove(bomb);
            }

            foreach (Enemy enemy in enemiesToRemove)
            {
                _ = Enemies.Remove(enemy);
            }

            AllDead(Enemies);
        }


        public void PlaceBomb()
        {
            if (_bombDelay >= 2)
            {
                Bombs.Add(new Bomb(Player.X, Player.Y));
                _bombDelay = 0;
            }
        }

        public bool ExplodeBomb(Bomb bomb, Entity entity)
        {
            int bombX = bomb.X;
            int bombY = bomb.Y;
            int entityX = entity.X;
            int entityY = entity.Y;

            return entityX >= bombX - 3 && entityX <= bombX + 3 &&
                   entityY >= bombY - 3 && entityY <= bombY + 3;
        }

        public void OnGameOver(bool isGameOver)
        {
            GameOver?.Invoke(this, new BombGameEventArgs(isGameOver, false));
        }

        public void OnGameWon(bool isGameWon)
        {
            GameWon?.Invoke(this, new BombGameEventArgs(false, isGameWon));
        }

        public void IsHit(Enemy enemy)
        {
            if (Player.X == enemy.X && Player.Y == enemy.Y)
            {
                OnGameOver(true);
            }
        }

        public void AllDead(List<Enemy> enemies)
        {
            if (enemies.Count == 0)
            {
                OnGameWon(true);
            }
        }

        public async Task LoadGameMap(MapSize mapSize)
        {
            if (_dataAccess == null)
            {
                throw new InvalidOperationException("No data access is provided.");
            }

            // Construct the embedded resource name based on the map size
            string resourceName = mapSize switch
            {
                MapSize.Small => "Bomb.Persistence.small.txt",
                MapSize.Medium => "Bomb.Persistence.medium.txt",
                MapSize.Large => "Bomb.Persistence.large.txt",
                _ => throw new InvalidOperationException("Invalid map size.")
            };

            // Get the assembly and open the resource stream
            Assembly assembly = Assembly.GetExecutingAssembly();
            using Stream? stream = assembly.GetManifestResourceStream(resourceName) ?? throw new FileNotFoundException($"Embedded resource '{resourceName}' not found.");

            // Use the stream to load the map
            Bombs.Clear();
            Map = await _dataAccess.LoadMap(stream);
        }
    }
}