﻿namespace Bomb.Model
{
    public class Entity
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Entity(int x, int y)
        {
            X = x;
            Y = y;
        }

        public void MoveUp()
        {
            Y -= 1;
        }

        public void MoveDown()
        {
            Y += 1;
        }

        public void MoveLeft()
        {
            X -= 1;
        }

        public void MoveRight()
        {
            X += 1;
        }
    }
}
