﻿namespace Bomb.Persistence
{
    public class MapFileDataException : Exception
    {
        public MapFileDataException() { }
    }
}
