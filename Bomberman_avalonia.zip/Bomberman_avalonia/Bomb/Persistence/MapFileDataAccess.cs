﻿namespace Bomb.Persistence
{
    public class MapFileDataAccess : IMapFileDataAccess
    {
        public async Task<Map> LoadMap(String path)
        {
            return await LoadMap(File.OpenRead(path));
        }

        public async Task<Map> LoadMap(Stream stream)
        {
            try
            {
                using StreamReader reader = new(stream);

                string line = await reader.ReadLineAsync() ?? string.Empty;
                int mapSize = int.Parse(line);
                Map map = new(mapSize);

                for (int i = 0; i < mapSize; i++)
                {
                    line = await reader.ReadLineAsync() ?? string.Empty;

                    for (int j = 0; j < mapSize; j++)
                    {
                        map.SetObject(i, j, int.Parse(line[j].ToString()));
                    }
                }

                return map;
            }
            catch
            {
                throw new MapFileDataException();
            }
        }
    }
}
