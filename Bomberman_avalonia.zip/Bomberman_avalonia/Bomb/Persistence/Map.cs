﻿namespace Bomb.Persistence
{
    public class Map
    {
        public int MapSize { get; }
        public int[,] ObjectMatrix { get; set; }

        public Map(int mapSize)
        {
            MapSize = mapSize;
            ObjectMatrix = new int[mapSize, mapSize];
        }

        public void SetObject(int x, int y, int objectValue)
        {
            ObjectMatrix[x, y] = objectValue;
        }
    }
}