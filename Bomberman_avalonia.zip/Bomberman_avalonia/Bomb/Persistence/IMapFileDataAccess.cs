﻿namespace Bomb.Persistence
{
    public interface IMapFileDataAccess
    {
        Task<Map> LoadMap(String path);

        Task<Map> LoadMap(Stream stream);
    }
}