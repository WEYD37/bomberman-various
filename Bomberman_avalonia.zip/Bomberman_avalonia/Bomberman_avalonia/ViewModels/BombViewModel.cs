﻿using Avalonia.Media;
using Bomb.Model;
using Bomberman_Avalonia.ViewModels;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using MsBox.Avalonia;
using MsBox.Avalonia.Enums;

namespace Bomberman_avalonia.ViewModels
{
    public class BombViewModel : ViewModelBase
    {
        private BombGameModel _model;
        private ObservableCollection<GridCell> _gameGrid;
        private int _mapSize;

        private bool _isPaused;
        private bool _isOver;
        private int _time;

        public bool IsPaused
        {
            get => _isPaused;
            private set
            {
                _isPaused = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(StartPauseLabel));
            }
        }

        public bool IsOver
        {
            get => _isOver;
            private set
            {
                _isOver = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(StartPauseLabel));
            }
        }

        public int Time
        {
            get => _time;
            set
            {
                _time = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(FormattedTime));
            }
        }

        public string StartPauseLabel => IsPaused ? "Start" : "Pause";
        public string GameScore => $"Score: {_model.Score}";
        public string FormattedTime => $"Time: {Time / 60:D2}:{Time % 60:D2}";

        public ICommand SmallMapCommand { get; }
        public ICommand MediumMapCommand { get; }
        public ICommand LargeMapCommand { get; }
        public ICommand PlaceBombCommand { get; }
        public ICommand StartGameCommand { get; }

        public ObservableCollection<GridCell> GameGrid
        {
            get => _gameGrid;
            private set { _gameGrid = value; OnPropertyChanged(); }
        }

        public int MapSize
        {
            get => _mapSize;
            private set { _mapSize = value; OnPropertyChanged(); }
        }

        public BombViewModel(BombGameModel model)
        {
            _model = model;
            _model.GameOver += OnGameOver;
            _model.GameWon += OnGameWon;
            _model.ScoreChanged += OnScoreChanged;
            _gameGrid = new ObservableCollection<GridCell>();

            SmallMapCommand = new RelayCommand(async () => await LoadMap(Bomb.Model.MapSize.Small));
            MediumMapCommand = new RelayCommand(async () => await LoadMap(Bomb.Model.MapSize.Medium));
            LargeMapCommand = new RelayCommand(async () => await LoadMap(Bomb.Model.MapSize.Large));

            PlaceBombCommand = new RelayCommand<object?>(_ =>
            {
                PlaceBomb();
            });

            StartGameCommand = new RelayCommand<object?>(_ =>
            {
                ToggleGamePause();
            });

            IsPaused = true;
            Time = 0;
        }

        private void OnScoreChanged(object? sender, EventArgs e)
        {
            OnPropertyChanged(nameof(GameScore));
        }

        private async void OnGameOver(object? sender, BombGameEventArgs e)
        {
            IsPaused = true;
            IsOver = true;

            var messageBoxStandard = MessageBoxManager
                .GetMessageBoxStandard("Game Over", "You lost the game!", ButtonEnum.Ok);
            await messageBoxStandard.ShowAsync();
        }

        private async void OnGameWon(object? sender, BombGameEventArgs e)
        {
            IsPaused = true;
            IsOver = true;

            var messageBoxStandard = MessageBoxManager
                .GetMessageBoxStandard("Congratulations!", "You won the game!", ButtonEnum.Ok);
            await messageBoxStandard.ShowAsync();
        }

        public void PlaceBomb()
        {
            if (!IsPaused)
            {
                _model.PlaceBomb();
            }
        }

        private async Task LoadMap(MapSize mapSize)
        {
            IsPaused = true;
            IsOver = false;
            Time = 0;
            _model.Score = 0;
            await _model.LoadGameMap(mapSize);
            MapSize = _model.Map.MapSize;

            _model.Enemies.Clear();
            GenerateGameGrid();
            _model.SpawnEntities();
        }

        private void GenerateGameGrid()
        {
            GameGrid.Clear();

            for (int i = 0; i < _model.Map.MapSize; i++)
            {
                for (int j = 0; j < _model.Map.MapSize; j++)
                {
                    var cell = new GridCell
                    {
                        X = i,
                        Y = j,
                        Color = GetCellColor(_model.Map.ObjectMatrix[i, j])
                    };
                    GameGrid.Add(cell);
                }
            }
        }

        private IBrush GetCellColor(int value)
        {
            return value switch
            {
                1 => Brushes.Gray,
                2 => Brushes.Blue,
                3 => Brushes.Red,
                _ => Brushes.White,
            };
        }

        public void ToggleGamePause()
        {
            if (!IsOver)
            {
                IsPaused = !IsPaused;
            }
        }

        public void IncrementTime()
        {
            if (!IsPaused)
            {
                Time++;
            }
        }
    }
}
