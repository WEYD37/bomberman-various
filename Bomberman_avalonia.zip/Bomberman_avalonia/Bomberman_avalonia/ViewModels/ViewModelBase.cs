﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Bomberman_avalonia.ViewModels;

public class ViewModelBase : ObservableObject
{
}
