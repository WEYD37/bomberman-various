﻿using Avalonia.Media;
using Bomberman_avalonia.ViewModels;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Bomberman_Avalonia.ViewModels
{
    public class GridCell : ViewModelBase
    {
        public int X { get; set; }
        public int Y { get; set; }

        private IBrush _color = null!;
        public IBrush Color
        {
            get => _color;
            set => SetProperty(ref _color, value);
        }
    }
}