﻿using Avalonia.Controls;

namespace Bomberman_avalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
