﻿using Avalonia.Controls;

namespace Bomberman_avalonia.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
