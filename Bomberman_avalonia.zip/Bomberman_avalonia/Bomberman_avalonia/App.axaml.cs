﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Input;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.Threading;
using Bomb.Model;
using Bomb.Persistence;
using Bomberman_avalonia.ViewModels;
using Bomberman_avalonia.Views;
using System;
using System.Linq;

namespace Bomberman_avalonia
{
    public partial class App : Application
    {
        private Point _touchStartPoint;
        private DateTime _lastTouchTime;
        private const int SwipeThreshold = 100;
        private const int DoubleTapThreshold = 500;

        private BombGameModel _model = null!;
        private BombViewModel _viewModel = null!;
        private DispatcherTimer _gameTimer = null!;

        public override void Initialize()
        {
            AvaloniaXamlLoader.Load(this);
        }

        public override void OnFrameworkInitializationCompleted()
        {
            if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
            {
                InitializeGameForDesktop(desktop);
            }
            else if (ApplicationLifetime is ISingleViewApplicationLifetime singleViewPlatform)
            {
                InitializeGameForMobile(singleViewPlatform);
            }

            base.OnFrameworkInitializationCompleted();
        }

        private void InitializeGameForDesktop(IClassicDesktopStyleApplicationLifetime desktop)
        {
            _model = new BombGameModel(new MapFileDataAccess());
            _viewModel = new BombViewModel(_model);

            var mainWindow = new MainWindow
            {
                DataContext = _viewModel
            };

            mainWindow.Background = Brushes.White;

            desktop.MainWindow = mainWindow;

            mainWindow.KeyDown += PlayerKeyDown;

            _gameTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _gameTimer.Tick += GameTimer_Tick;
            _gameTimer.Start();
        }

        private void InitializeGameForMobile(ISingleViewApplicationLifetime singleViewPlatform)
        {
            _model = new BombGameModel(new MapFileDataAccess());
            _viewModel = new BombViewModel(_model);

            var mainView = new MainView
            {
                DataContext = _viewModel
            };

            singleViewPlatform.MainView = mainView;

            mainView.PointerPressed += PlayerTouchDown;
            mainView.PointerMoved += PlayerTouchMove;

            _gameTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _gameTimer.Tick += GameTimer_Tick;
            _gameTimer.Start();
        }


        private void PlayerKeyDown(object? sender, KeyEventArgs e)
        {
            if (!_viewModel.IsPaused)
            {
                HandleMovement(e.Key);
            }
        }

        private void PlayerTouchDown(object? sender, PointerPressedEventArgs e)
        {
            if (_viewModel.IsPaused)
                return;

            var touchPoint = e.GetPosition(sender as Control);

            var currentTime = DateTime.Now;
            if ((currentTime - _lastTouchTime).TotalMilliseconds < DoubleTapThreshold)
            {
                _viewModel.PlaceBombCommand.Execute(null);
            }
            _lastTouchTime = currentTime;

            _touchStartPoint = touchPoint;
        }

        private void PlayerTouchMove(object? sender, PointerEventArgs e)
        {
            if (_viewModel.IsPaused)
                return;

            var touchPoint = e.GetPosition(sender as Control);

            var deltaX = touchPoint.X - _touchStartPoint.X;
            var deltaY = touchPoint.Y - _touchStartPoint.Y;

            if (Math.Abs(deltaX) > SwipeThreshold || Math.Abs(deltaY) > SwipeThreshold)
            {
                UpdateCell(_model.Player.X, _model.Player.Y, Brushes.White);

                if (Math.Abs(deltaY) > Math.Abs(deltaX))
                {
                    if (deltaY > 0 && _model.Map.ObjectMatrix[_model.Player.X + 1, _model.Player.Y] != 1)
                    {
                        _model.Player.MoveRight();
                    }
                    else if(_model.Map.ObjectMatrix[_model.Player.X - 1, _model.Player.Y] != 1)
                    {
                        _model.Player.MoveLeft();
                    }
                }
                else
                {
                    if (deltaX > 0 && _model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y + 1] != 1)
                    {
                        _model.Player.MoveDown();
                    }
                    else if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y - 1] != 1)
                    {
                        _model.Player.MoveUp();
                    }
                }

                _touchStartPoint = touchPoint;

                UpdateCell(_model.Player.X, _model.Player.Y, Brushes.Blue);

                foreach (var enemy in _model.Enemies)
                {
                    _model.IsHit(enemy);
                }
            }
        }

        private void HandleMovement(Key key)
        {
            UpdateCell(_model.Player.X, _model.Player.Y, Brushes.White);

            switch (key)
            {
                case Key.A:
                    if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y - 1] != 1)
                    {
                        _model.Player.MoveUp();
                    }
                    break;
                case Key.D:
                    if (_model.Map.ObjectMatrix[_model.Player.X, _model.Player.Y + 1] != 1)
                    {
                        _model.Player.MoveDown();
                    }
                    break;
                case Key.W:
                    if (_model.Map.ObjectMatrix[_model.Player.X - 1, _model.Player.Y] != 1)
                    {
                        _model.Player.MoveLeft();
                    }
                    break;
                case Key.S:
                    if (_model.Map.ObjectMatrix[_model.Player.X + 1, _model.Player.Y] != 1)
                    {
                        _model.Player.MoveRight();
                    }
                    break;
                case Key.Space:
                    _viewModel.PlaceBombCommand.Execute(null);
                    break;
            }

            UpdateCell(_model.Player.X, _model.Player.Y, Brushes.Blue);

            foreach (var enemy in _model.Enemies)
            {
                _model.IsHit(enemy);
            }
        }

        private void GameTimer_Tick(object? sender, EventArgs e)
        {
            if (_viewModel.IsPaused || _model.Map == null)
            {
                return;
            }

            ClearEntities();
            _model.MoveEnemies();
            _model.UpdateGameState();
            DrawEntities();

            _viewModel.IncrementTime();
        }

        private void UpdateCell(int x, int y, IBrush color)
        {
            var cell = _viewModel.GameGrid.FirstOrDefault(c => c.X == x && c.Y == y);
            if (cell != null)
            {
                cell.Color = color;
            }
        }

        private void DrawEntities()
        {
            UpdateCell(_model.Player.X, _model.Player.Y, Brushes.Blue);
            foreach (var enemy in _model.Enemies)
            {
                UpdateCell(enemy.X, enemy.Y, Brushes.Red);
            }
            foreach (var bomb in _model.Bombs)
            {
                UpdateCell(bomb.X, bomb.Y, Brushes.Black);
            }
        }

        private void ClearEntities()
        {
            UpdateCell(_model.Player.X, _model.Player.Y, Brushes.White);
            foreach (var enemy in _model.Enemies)
            {
                UpdateCell(enemy.X, enemy.Y, Brushes.White);
            }
            foreach (var bomb in _model.Bombs)
            {
                UpdateCell(bomb.X, bomb.Y, Brushes.White);
            }
        }
    }
}
